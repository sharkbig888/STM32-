#include "stm32f10x.h"  
#include "Led.h"
#include "Key.h"
#include "OLED.h"
#include "Timer.h"
#include "Delay.h"
//#include "AD.h"
#include "DHT11.h"
#include "Buzzer.h"
#include "usart.h"
#include "esp8266.h"
#include "onenet.h"
#include "MPU6050.h"
#include "string.h"
#include <stdio.h>
uint8_t ID;								//�������ڴ��ID�ŵı���
int16_t AX, AY, AZ, GX, GY, GZ;			//�������ڴ�Ÿ������ݵı���
uint8_t Key_Num=0;
uint16_t Num=0;
uint16_t AD_Value=0;
float AD_Num=0;
uint8_t RXData=0;
unsigned  char KEY_FLAG=0;
const char *devSubTopic[] = {"testtopic2"};//��������
const char devPubTopic[] = "testtopic1";//��������
char PUB_Buf[256];//�ϴ�����ת��buf1
int main()
{
	OLED_Init();
	OLED_ShowString(24,24,"Loading......",OLED_8X16);
	OLED_Update();
	LED_Init();
	Key_Init();
	Timer_Init();
//	AD_Init();
	MPU6050_Init();

	Usart1_Init(115200);
	USART3_Init(115200);
	
	ESP8266_Init();
	UsartPrintf(USART1, " Hardware init OK\r\n");
	while(OneNet_DevLink());			//����OneNET
	
	Delay_ms(500);
	Buzzer_ON();
	Delay_ms(500);
	Buzzer_OFF();
	unsigned short timeCount = 0;	//���ͼ������
	unsigned char *dataPtr = NULL;
	OneNet_Subscribe(devSubTopic, 1);
	OLED_Clear();
	OLED_ShowString(8,24,"SUCCESS CONNECT!",OLED_8X16);
	OLED_Update();
	Delay_s(1);
	LED1_ON();
	LED2_ON();
//	LED3_ON();
//	LED4_ON();
//	LED5_ON();
//	LED6_ON();
	OLED_Clear();
	OLED_ShowString(48,0,"MQTT",OLED_8X16);
	OLED_ShowString(0,16,"AutoKey: ",OLED_8X16);
//	OLED_ShowChinese(48,16,"开");
//	OLED_Update();
//	OLED_ShowString(0,16,"ADValue:",OLED_8X16);
//	OLED_ShowString(106,16,"V",OLED_8X16);
	OLED_ShowString(0,32,"Temp: ",OLED_8X16);
	OLED_ShowString(0,48,"Humi:",OLED_8X16);
	
  
	while(1) 
	{ 
//		OLED_ShowNum(32,0,Num,4,OLED_8X16);
//		OLED_Update();
		Key_Num=Key_GetNum();
		if(KEY_FLAG==0)//�Զ����ֶ�����
		{
			if(Key_Num==1)//����LED1
			{
				LED1_Turn();
			}
			else if(Key_Num==2)//����LED1
			{
				LED2_Turn();
			}
			else if(Key_Num==3)//����LED1
			{
				LED3_Turn();
			}
			else if(Key_Num==4)//����LED1
			{
				LED4_Turn();
			}
			else if(Key_Num==5)//����LED1
			{
				LED5_Turn();
				LED6_Turn();
				Buzzer_Turn();
			}
		}
		if(Key_Num==6)//�Զ����ƿ���
		{
			KEY_FLAG=~KEY_FLAG;	
		}
		if(KEY_FLAG==0)
		{
			OLED_ShowChinese(64,16,"开");
			OLED_Update();
		}
		else
		{
			OLED_ShowChinese(64,16,"关");
			OLED_Update();
		}
		
			
//		AD_Value=AD_GetValue();
//		AD_Num=(float)AD_Value/4095*3.3;
//		OLED_ShowFloatNum(64,16,AD_Num,1,2,OLED_8X16);
//		OLED_Update();
//		MPU6050_GetData(&AX, &AY, &AZ, &GX, &GY, &GZ);		//��ȡMPU6050������
//		OLED_ShowSignedNum(0, 0, AX, 5,OLED_8X16);					//OLED��ʾ����
//		OLED_ShowSignedNum(0, 16, AY, 5,OLED_8X16);
//		OLED_ShowSignedNum(0, 32, AZ, 5,OLED_8X16);
//		OLED_ShowSignedNum(0, 48, GX, 5,OLED_8X16);
//		OLED_ShowSignedNum(0, 64, GY, 5,OLED_8X16);
//		OLED_ShowSignedNum(0, 84, GZ, 5,OLED_8X16);
		uint8_t buffer[5];
		uint8_t LED1_State=1,Buzzer_State=1;
		double humi,temp;
        if (dht11_read_data(buffer) == 0)
        {
            humi = buffer[0] + buffer[1] / 10.0;
            temp = buffer[2] + buffer[3] / 10.0;
        }
		OLED_ShowFloatNum(36,32,temp,2,2,OLED_8X16);
		OLED_ShowFloatNum(36,48,humi,2,2,OLED_8X16);
		OLED_Update();
		if(++timeCount >= 50)									//���ͼ��5s
		{
			UsartPrintf(USART_DEBUG,"temp:%f,humi:%f\r\n",temp,humi);
			UsartPrintf(USART_DEBUG, "OneNet_Publish\r\n");
			LED1_State=(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_4));
			Buzzer_State=(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_12));
			sprintf(PUB_Buf,"{\"Temp\":%f,\"Humi\":%f,\"LED\":%d,\"Buzzer\":%d,\"AutoFlag\":%d}",temp,humi,LED1_State ?0:1,Buzzer_State?0:1,KEY_FLAG);
			OneNet_Publish("testtopic1",PUB_Buf);
			
			timeCount = 0;
			ESP8266_Clear();
		}
		
		dataPtr = ESP8266_GetIPD(3);
		if(dataPtr != NULL)
		OneNet_RevPro(dataPtr);
		Delay_ms(10);
	}
}
//==========================================================
//	�������ƣ�	USART3_IRQHandler
//
//	�������ܣ�	����3�շ��ж�
//
//	��ڲ�����	��
//
//	���ز�����	��
//
//	˵����		
//==========================================================

