1.ESP8266连接：确保串口正常使用；RST->AT->AT+CWMODE->CWJAP->CIPSTART;

        CWJAP连接WIFI,CIPSTART连接平台网站；

2.与平台进行连接：调用MQTT协议包，

3.进行消息的发布：设置发送间隔，用JSON格式进行发送

4.通过ESP8266获取平台下发的数据，捕获数据包，在调用解包函数进行解包，利用 cJSON进行解包，获取信息，进行设备的控制。


