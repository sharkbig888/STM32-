#include "stm32f10x.h"                  // Device header

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1| GPIO_Pin_0| GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_15 | GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_2| GPIO_Pin_4);
	
	GPIO_SetBits(GPIOC, GPIO_Pin_13 | GPIO_Pin_15 | GPIO_Pin_14);
}

void LED1_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_4);
}

void LED1_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_4);
}

void LED1_Turn(void)
{
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==1)
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	}
	else
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_4);
	}
}


void LED2_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_1);
}

void LED2_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
}

void LED2_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_1) == 0)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_1);
	}
	else
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_1);
	}
}

void LED3_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_0);
}

void LED3_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_0);
}

void LED3_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_0) == 0)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_0);
	}
	else
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_0);
	}
}

void LED4_ON(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_15);
}

void LED4_OFF(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_15);
}

void LED4_Turn(void)
{
	if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_15)==1)
	{
		GPIO_ResetBits(GPIOC,GPIO_Pin_15);
	}
	else
	{
		GPIO_SetBits(GPIOC,GPIO_Pin_15);
	}
}


void LED5_ON(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_14);
}

void LED5_OFF(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_14);
}

void LED5_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_14) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_14);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_14);
	}
}

void LED6_ON(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);
}

void LED6_OFF(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

void LED6_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13) == 0)
	{
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
	}
	else
	{
		GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	}
}

