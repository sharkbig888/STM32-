#include "stm32f10x.h"                  // Device header
#include "stdio.h"
#include "stdarg.h"
uint8_t Serial_RXPacket[4];
uint8_t Serial_TXPacket[4];
uint8_t Serial_RXFlag=0;

uint8_t Serial2_RXPacket[4];
uint8_t Serial2_TXPacket[4];
uint8_t Serial2_RXFlag=0;
void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_10;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate=115200;
	USART_InitStruct.USART_HardwareFlowControl=USART_HardwareFlowControl_None ;
	USART_InitStruct.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_InitStruct.USART_Parity=USART_Parity_No;
	USART_InitStruct.USART_StopBits=USART_StopBits_1;
	USART_InitStruct.USART_WordLength=USART_WordLength_8b;
	USART_Init(USART1,&USART_InitStruct);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel= USART1_IRQn ;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_InitStruct);
	
	USART_Cmd(USART1,ENABLE);
}

void Serial2_Init(void)
{
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	GPIO_InitTypeDef GPIO_InitStruct;
	
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
//	
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO,ENABLE);
	
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	

	USART_InitStruct.USART_BaudRate=115200;
	USART_InitStruct.USART_HardwareFlowControl=USART_HardwareFlowControl_None ;
	USART_InitStruct.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;
	USART_InitStruct.USART_Parity=USART_Parity_No;
	USART_InitStruct.USART_StopBits=USART_StopBits_1;
	USART_InitStruct.USART_WordLength=USART_WordLength_8b;
	USART_Init(USART2,&USART_InitStruct);
	USART_Cmd(USART2,ENABLE);
	
	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	
	NVIC_InitStruct.NVIC_IRQChannel= USART2_IRQn ;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_InitStruct);
	
	
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1,Byte);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET);
}

void Serial2_SendByte(uint8_t Byte)
{
	USART_SendData(USART2,Byte);
	while(USART_GetFlagStatus(USART2,USART_FLAG_TXE) == RESET);
}

void Serial_SendArray(uint8_t *Array,uint16_t Length)
{
	uint16_t i=0;
	for(i=0;i<Length;i++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial2_SendArray(uint8_t *Array,uint16_t Length)
{
	uint16_t i=0;
	for(i=0;i<Length;i++)
	{
		Serial2_SendByte(Array[i]);
	}
}

void Serial_SendString(char *String )
{
	uint8_t i=0;
	for(i=0;String[i]!='\0';i++)
	{
		Serial_SendByte(String[i]);
	}
}

void Serial2_SendString(unsigned char *str,unsigned short len)
{
	unsigned short count = 0;
	for(; count < len; count++)
	{
		USART_SendData(USART2, *str++);									//��������
		while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);		//�ȴ��������
	}
}
uint32_t Serial_Pow(uint32_t X,uint32_t Y)
{
	uint32_t Result=1;
	while(Y--)
	{
		Result*=X;
	}
	return Result;
}

void Serial_SendNum(uint32_t Num,uint8_t Length)
{
	uint8_t i=0;
	for(i=0;i<Length;i++)
	{
		Serial_SendByte(Num/Serial_Pow(10,Length-1-i)%10+'0');
	}
}

void Serial2_SendNum(uint32_t Num,uint8_t Length)
{
	uint8_t i=0;
	for(i=0;i<Length;i++)
	{
		Serial2_SendByte(Num/Serial_Pow(10,Length-1-i)%10+'0');
	}
}

int fputc(int ch,FILE*f)
{
	Serial_SendByte(ch);
	return ch;
}

void Serial_Printf(char *format,...)
{
	char String[100];
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	Serial_SendString(String);
}
uint8_t  Serial_GetRXFlag(void)
{
	if(Serial_RXFlag==1)
	{
		Serial_RXFlag=0;
		return 1;
	}
	return 0;
}

uint8_t  Serial2_GetRXFlag(void)
{
	if(Serial2_RXFlag==1)
	{
		Serial2_RXFlag=0;
		return 1;
	}
	return 0;
}

void Serial_SendPacket(uint8_t *Serial_TXPacket)
{
	Serial_SendByte(0xff);
	Serial_SendArray(Serial_TXPacket,4);
	Serial_SendByte(0xfe);
}

void Serial3_SendPacket(uint8_t *Serial_TXPacket)
{
	Serial2_SendByte(0xff);
	Serial2_SendArray(Serial_TXPacket,4);
	Serial2_SendByte(0xfe);
}
void USART1_IRQHandler(void)
{
	static uint8_t RXState=0;
	static uint8_t NRXPacket=0;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
	{
		uint8_t RXData=USART_ReceiveData(USART1);
		if(RXState==0)
		{
			if(RXData==0XFF)
			{
				RXState=1;
			}
		}
		else if(RXState==1)
		{
			Serial_RXPacket[NRXPacket]=RXData;
			NRXPacket++;
			if(NRXPacket>=4)
			{
				RXState=2;
			}
		}
		else if(RXState==2)
		{
			if(RXData==0XFE)
			{
				RXState=0;
				Serial_RXFlag=1;
			}
		}
		
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
	}
}

//void USART3_IRQHandler(void)
//{
//	static uint8_t RXState3=0;
//	static uint8_t NRXPacket3=0;
//	if(USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
//	{
//		uint8_t RXData3=USART_ReceiveData(USART3);
//		if(RXState3==0)
//		{
//			if(RXData3==0XFF)
//			{
//				RXState3=1;
//			}
//		}
//		else if(RXState3==1)
//		{
//			Serial3_RXPacket[NRXPacket3]=RXData3;
//			NRXPacket3++;
//			if(NRXPacket3>=4)
//			{
//				RXState3=2;
//			}
//		}
//		else if(RXState3==2)
//		{
//			if(RXData3==0XFE)
//			{
//				RXState3=0;
//				Serial3_RXFlag=1;
//			}
//		}
//		
//		USART_ClearITPendingBit(USART3,USART_IT_RXNE);
//	}
//}

