#ifndef __LIGHTSENSOR_H__
#define __LIGHTSENSOR_H__

#include "stm32f10x.h"

#define RCC_ILLUME_GPIO               RCC_APB2Periph_GPIOA
#define RCC_ADC                       RCC_APB2Periph_ADC1

#define ILLUME_ADC                    ADC1
#define ILLUME_ADC_CHANNEL            ADC_Channel_4

#define PORT_ILLUME                   GPIOA

#define GPIO_ILLUME_AO                GPIO_Pin_4
#define GPIO_ILLUME_DO                GPIO_Pin_14

#define GET_DO_IN        GPIO_ReadInputDataBit(PORT_ILLUME, GPIO_ILLUME_DO)

void Illume_GPIO_Init(void);
uint32_t Get_Adc_Value(uint8_t Count);
unsigned int Get_illume_Percentage_value(void);
uint8_t Get_DO_In(void);

#endif
