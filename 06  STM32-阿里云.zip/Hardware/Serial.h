#ifndef __SERIAL_H
#define __SERIAL_H
#include "stdio.h"
extern uint8_t Serial_TXPacket[];
extern uint8_t Serial_RXPacket[];
void Serial_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array,uint16_t Length);
void Serial_SendString(char *String );
void Serial_SendNum(uint32_t Num,uint8_t Length);
void Serial_Printf(char *format,...);
void Serial_SendPacket(uint8_t *Serial_TXPacket);
uint8_t  Serial_GetRXFlag(void);

extern uint8_t Serial2_TXPacket[];
extern uint8_t Serial2_RXPacket[];
void Serial2_Init(void);
void Serial2_SendByte(uint8_t Byte);
void Serial2_SendArray(uint8_t *Array,uint16_t Length);
void Serial2_SendString(unsigned char *String );
void Serial2_SendNum(uint32_t Num,uint8_t Length);
void Serial2_Printf(char *format,...);
void Serial2_SendPacket(uint8_t *Serial_TXPacket);
uint8_t  Serial2_GetRXFlag(void);
#endif
