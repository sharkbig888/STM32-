//  index.js
//获取应用实例

const app=getApp()

const {connect} = require('../../utils/mqtt.min')


const mqttHost='broker.emqx.io'//mqtt服务器域名
const mqttPort= 8084//mqtt服务器端口

const deviceSubTopic = 'testtopic1'//设备订阅Topic
const devicePubTopic = 'testtopic2'//设备发布Topic

const mpSubTopic = deviceSubTopic
const mpPubTopic = devicePubTopic

Page({
    data:{
        client:null,
        Temp:0,
        Humi:0,
        Led:false,
        Buzzer:false,
        AutoFlag:false
    },
    
    onLedChange(event){
        const that =this
        console.log(event.detail.value);
        const sw=event.detail.value
        that.setData({Led:sw})
        if(sw)
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                target:"LED",
                value:1
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，开灯');
                }
            })
        }
        else
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                target:"LED",
                value:0
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，关灯');
                }
            }) 
        }

    },
    onBuzzerChange(event){
        const that =this
        console.log(event.detail.value);
        const sw=event.detail.value
        that.setData({Buzzer:sw})
        if(sw)
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                "target":"Buzzer",
                "value":1
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，开报警器');
                }
            })
        }
        else
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                "target":"Buzzer",
                "value":0
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，关报警器');
                }
            }) 
        }

    },
    onAutoChange(event){
        const that =this
        console.log(event.detail.value);
        const sw=event.detail.value
        that.setData({AutoFlag:sw})
        if(sw)
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                target:"AutoFlag",
                value:255
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，自动控制开');
                }
            })
        }
        else
        {
            that.data.client.publish(mpPubTopic,JSON.stringify({
                target:"AutoFlag",
                value:0
            }),function (err) {
                if(!err)
                {
                    console.log('成功下发指令，自动控制关');
                }
            }) 
        }

    },
    // 事件处理函数
    onShow(){
        const that = this
        that.setData({
            //wxs   实际上就是 wss => wss 实际上就是拥有WEBSOCKET加密通信的websocket协议 
            client :connect('wxs://broker.emqx.io:8084/mqtt')
        })
        that.data.client.on('connect',function (params) {
            console.log('连接成功MQTT');
            wx.showToast({
              title: '连接成功',
              icon:'success',
              mask: true
            })
        that.data.client.subscribe(mpSubTopic,function (err) {
            if(!err)
            {
                 console.log('成功订阅设备Topic');
            }
            })
        })
        that.data.client.on('message',function (topic,message) {
                 console.log(topic)
                //MESSAGE 是16进制字符流   
                 let dataFromDev={}
                 try {
                      dataFromDev=JSON.parse(message)
                      console.log(dataFromDev);
                      that.setData({
                            Temp:dataFromDev.Temp,
                            Humi:dataFromDev.Humi,
                            Led:dataFromDev.Led,
                            Buzzer:dataFromDev.Buzzer,
                            AutoFlag:dataFromDev.AutoFlag,
                      })
                 } catch (error) {
                    console.log(error);
                 }
         
             })
    }
})