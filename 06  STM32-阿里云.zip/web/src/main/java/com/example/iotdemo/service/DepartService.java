package com.example.newdemo.service;

import com.example.newdemo.bean.Depart;

import java.util.List;

public interface DepartService {
    public List<Depart> selectAll();
}