package com.example.iotdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(IotdemoApplication.class, args);
    }

}
