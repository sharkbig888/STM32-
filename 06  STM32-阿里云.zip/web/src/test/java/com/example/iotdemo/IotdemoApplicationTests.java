package com.example.iotdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IotdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
