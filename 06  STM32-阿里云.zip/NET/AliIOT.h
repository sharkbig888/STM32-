#ifndef __ALIIOT_H
#define __ALIIOT_H

#include "MQTT.h"
#include "esp8266.h"


																																					//�����������˿ڣ��̶�1883
#define CLIENTID				"k19g7lmaIxi.device2|securemode=2,signmethod=hmacsha256,timestamp=1729941746012|"	//�����¼������
#define PASSWD					"4e14d41972b488fecd4ac910810edb747401d32fd74040c1827b8f096c45bb79"										//�ͻ���ID
#define USERNAME				"device2&k19g7lmaIxi"

_Bool AliIOT_Link(void);
void AliIOT_Subscribe(const char *topics[], unsigned char topic_cnt);
void ALiIOT_Publish(const char *topic, const char *msg);
void ALiIOT_RevPro(unsigned char *cmd);
#endif
