#ifndef __LED_H
#define __LED_H
void Led_Init(void);
void Led_Close(void);
void Led_Open(void);
#endif
